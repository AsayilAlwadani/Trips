<?php
require_once('header.php');
include_once("../backend/db.php");

$records = mysqli_query($con,"select * from trips");
if(isset($_POST['delete'])) {

    $id = $_POST['id'];
    $sql = "DELETE FROM trips where `id`='$id'";
    mysqli_query($con, $sql) or die("database error:". mysqli_error($con)."qqq".$sql);
  
    echo '<script type="text/javascript"> alert("Account deleted successfully!"); window.location.href="trips.php";</script>';  // alert message
  }
?>

<style>
    body {
        background: #333;
        font-family: system-ui;
    }

    .table-wrapper {
        width: 100%;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        background: #444;
        margin-top:5%;
    }

    caption,
    th,
    td {
        padding: 1rem;
        text-align: left;
        line-height: 1.5;
        color: white;
    }
    tr:nth-of-type(2n) {
        background: hsl(0% 0% 05 / 0.1);
    }

    @media only screen and (max-width: 650px) {
        th {
            display: none;
        }
        td {
            display: grid;
            grid-template-columns: 15ch auto;
        }

        td::before {
            content: attr(data-cell) ": ";
            font-weight: 700;
            text-transform: capitalize;
        }
    }

</style>


<div class="table-wrapper">
	<div class="table-container">
		<table class="container">
			<caption>DEPARTURES</caption>
			<tbody>
				<tr>
					<th>Time</th>
					<th>Destination</th>
					<th>Flight</th>
				</tr>
                <?php
                while($data = mysqli_fetch_array($records))
                {
                ?>
				<tr>
					<td data-cell="Time"><?php echo $data['time']?></td>
					<td data-cell="Destination"><?php echo $data['destination']?></td>
					<td data-cell="Flight"><?php echo $data['flight']?></td>
				</tr>
                <?php
                }
                ?>

			</tbody>
		</table>
	</div>
</div>

<?php
    require_once('footer.php');
?>