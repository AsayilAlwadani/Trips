<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
    <link rel="stylesheet" href="./css/main.css">
</head>
<body>
<header class="hero">
      <nav class="navbar">
         <h1 class="logo">
         <a href="index.php"><img src="img/logo.jfif" alt="" style="width:150px;height:auto;margin-top:-45px"></span></a>
         </h1>
         <div>
            <!-- --------------------------------------
            -------- Hamburger Links ------------
            --------------------------------------- -->
            <div class="nav-menu">
               <!-- Header icons -->
               <a href="index.php" class="nav-link">Home</a>
               <a href="login.php" class="nav-link">Login</a>
               <a href="signup.php" class="nav-link">Signup</a>
            </div>

            <!-- --------------------------------------
            ---------- Hamburger button ---------------
            --------------------------------------- -->
            <div class="hamburger">
               <span class="bar"></span>
               <span class="bar"></span>
               <span class="bar"></span>
            </div>
         </div>
      </nav>
      <input id="user" type="hidden" value="<?php echo $x; ?>">
   </header>
   <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.10.2/umd/popper.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js"></script>
   
   <script src="../js/header.js"></script>
</body>
</html>