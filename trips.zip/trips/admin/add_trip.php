<?php
require_once('header.php');
?>
<style>
    section{
        padding-top: 50px;
        background: url('https://qa.trip.ae/system/image/open_graph_default_image.jpg') center center;
        background-size: cover;
    }
    h2{text-align:center;}
    /* Forms */

    [type=text],
    [type=time],
    [type=file],
    select,
    textarea {
    display: block;
    padding: .5rem;
    background: transparent;
    vertical-align: middle;
    width: 100%;
    max-width: 100%;
    border: 1px solid #cdcdcd;
    border-radius: 4px;
    font-size: .95rem;
    color: white;
    }

    [type=text]:focus,
    [type=time]:focus,
    [type=file]:focus,
    select:focus,
    textarea:focus {
    outline: none;
    border: 1px solid #1E6BD6;
    } 

    select {
    -webkit-appearance: none;
    -moz-appearance: none;
    background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAAJCAYAAAA/33wPAAAAvklEQVQoFY2QMQqEMBBFv7ERa/EMXkGw11K8QbDXzuN4BHv7QO6ifUgj7v4UAdlVM8Uwf+b9YZJISnlqrfEUZVlinucnBGKaJgghbiHOyLyFKIoCbdvecpyReYvo/Ma2bajrGtbaC58kCdZ1RZ7nl/4/4d5EsO/7nzl7IUtodBexMMagaRrs+06JLMvcNWmaOv2W/C/TMAyD58dxROgSmvxFFMdxoOs6lliWBXEcuzokXRbRoJRyvqqqQvye+QDMDz1D6yuj9wAAAABJRU5ErkJggg==) 100% no-repeat;
    line-height: 1
    }

    label {
    font-weight: 600;
    font-size: .9rem;
    display: block;
    margin: .5rem 0;
    }

    /* Other */

    * { box-sizing: border-box; }

    html {
    -webkit-font-smoothing: antialiased;
    }

    .c1 {
    margin: 0 auto;
    padding: 0 1rem;
    background-color: #000000a6;
    color: white;
    padding: 10px 10px;
    border: 1px groove;
    border-radius: 20px;
    }


    /* Button */

    [type=submit] {
    display: inline-block;
    vertical-align: middle;
    white-space: nowrap;
    cursor: pointer;
    margin: .25rem 0;
    padding: .5rem 1rem;
    border: 1px solid #1E6BD6;
    border-radius: 18px;
    background: #1E6BD6;
    color: white;
    font-weight: 600;
    text-decoration: none;
    font-family: sans-serif;
    font-size: .95rem;
    }
</style>

<section class="all">
    <div class="container c1">
        <h2><b>Add New Trip</b></h2>
    <form method="post" action="../backend/addtrip.php" enctype="multipart/form-data">
        <div class="row">
            <div class="col-md-12">
                <label for="title">Trip Time</label>
                <input type="time" name="time" id="title">
            </div>
            <div class="col-md-12">
                <label for="requirements">Trip Destination</label>
                <input type="text" name="destination" id="requirements" placeholder="Trip Destination">
            </div>
            <div class="col-md-12">
                <label for="requirements">Flight Number</label>
                <input type="text" name="flight" id="requirements" placeholder="Flight Number">
            </div>
           
        </div>
        
        <input type="submit" name="submit_trip" value="Add Trip">
    </form>
    </div>
</section>

<?php
    require_once('footer.php');
?>