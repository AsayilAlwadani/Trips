<?php
require_once('header.php');
include_once("../backend/db.php");

$url = "http://";
// Append the host(domain name, ip) to the URL.   
$url.= $_SERVER['HTTP_HOST'];   
    
// Append the requested resource location to the URL   
$url.= $_SERVER['REQUEST_URI'];

$url_components = parse_url($url);
// Use parse_str() function to parse the
// string passed via URL
parse_str($url_components['query'], $params);

$id = $params['id'];
$records = mysqli_query($con,"select * from trips where id='$id'");

?>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins&display=swap');

    section {
    background : beige ;
    margin : 0 ;
    padding : 0 ;
    transition: all .3s;
    }
    ::-webkit-scrollbar {
    width: 5px;
    }
    ::-webkit-scrollbar-thumb {
    background:rgba(255, 99, 71, .3);
    border-radius:2px;
    }
    ::-webkit-scrollbar-thumb:hover {
    background:rgba(255, 99, 71, .9);
    border-radius:2px;
    }
    .container {
    width: 100%;
    margin: 0 auto;
    display :flex;
    justify-content:space-evenly;
    flex-wrap:wrap;
    gap: 15px;
    }

    .card{
    margin : auto;
    width: 350px;
    overflow : hidden;
    border-radius : 20px;
    background : white;
    margin-top:50px;
    transition: all .5s;
    box-shadow:5px 5px 15px rgba(0,0,0, .3);
    }

    .card:hover {
    box-shadow:5px 5px 25px rgba(0,0,0, .5);
    transform: translate(-5px, -5px);
    }

    .card:hover .icon svg{
    animation : iconjln 1s;
    }

    .img-cover{
    position: relative;
    }

    .card img{
    width: 350px;
    height:350px;
    object-fit:cover;
    }

    .icon{
    position:absolute;
    top:0;
    padding : 25px;
    right:0;
    border-bottom-left-radius:20px;
    backdrop-filter: blur(20px);
    background-color: rgba(255, 255, 255, 0.5);
    cursor: pointer;
    color: black;
    font-weight: 800;
    }

    .desc{
    padding : 1.5em ;
    font-family: 'Poppins', sans-serif;
    color: black;
    text-align: center;
    }
    .desc h1{
    }
    .tdesc{
    margin-bottom:40px;
    width:100%;
    height:50px;
    overflow: auto;
    }

    .desc button{
    text-decoration: none;
    background-color: #ee1b24;
    padding: 15px 25px;
    color:white;
    border-radius: 15px;
    display:block;
    text-align: center;
    transition: all .2s;
    }

    .desc button:hover svg{
    animation : iconjln 1s;
    }

    @keyframes iconjln{
    0%, 100% {
        opacity : 1;
        transform: translateX(0%);
    }
    50%{
        opacity:0;
        transform: translateX(100%);
    }
    70%{
        opacity:0;
        transform:translateX(-100%);
    }
    }

</style>
<section>
    <div class="container">

        <form method="post" action="../backend/addtrip.php" enctype="multipart/form-data">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Trip</h5>

                </div>
                <div class="modal-body">
                    <div class="row">
                    <?php while($data = mysqli_fetch_array($records)){ ?>
                        <div class="col-md-12">
                            <label for="title">Trip Time</label>
                            <input type="time" class="form-control" name="time" id="title" value="<?php echo $data['time']; ?>">
                        </div>
                        <div class="col-md-12">
                            <label for="desc">Trip Destination</label>
                            <input type="text" class="form-control" name="destination" id="desc" value="<?php echo $data['destination']; ?>">
                        </div>
                        <div class="col-md-12">
                            <label for="desc">Flight Number</label>
                            <input type="text" class="form-control" name="flight" id="desc" value="<?php echo $data['flight']; ?>">
                        </div>
                        <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
                    <?php } ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="edit_flight" class="btn btn-primary">Edit Trip</button>
                </div>
                </div>
            </div>
        </form>

    </div>
</section>

<?php
    require_once('footer.php');
?>