<?php
include_once("./db.php");

if(isset($_POST['submit_trip'])) {

    $time = $_POST['time'];
    $destination = $_POST['destination'];
    $flight = $_POST['flight'];

    $sql = "INSERT INTO trips(`time`, `destination`, `flight`) VALUES ('$time', '$destination', '$flight')";
    mysqli_query($con, $sql) or die("database error:". mysqli_error($con)."qqq".$sql);

    echo '<script type="text/javascript"> alert("Trip added successfully!"); window.location.href="../admin/trips.php";</script>';  // alert message
	
}


else if(isset($_POST['edit_flight']))
{
    $id = $_POST['id'];
    $time = $_POST['time'];
    $destination = $_POST['destination'];
    $flight = $_POST['flight'];

    $sql = "UPDATE trips set `time`='$time', `destination`='$destination', `flight`='$flight' where `id`='$id'";
    mysqli_query($con, $sql) or die("database error:". mysqli_error($con)."qqq".$sql);

    echo '<script type="text/javascript"> alert("Trip Updated successfully!"); window.location.href="../admin/trips.php";</script>';  // alert message
}

?>