<?php
//kill session
session_start();
$_SESSION["login"] = '';
$_SESSION["user"] = '';
$_SESSION["email"] = '';
header("Location: ../index.php");
?>