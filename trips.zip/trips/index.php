<?php
    require_once('header.php');
?>

<style>
.txt{
    position: absolute;
    top: 45%;
    left: 34%;
    text-align: center;
    background-color: #00000066;
    color: white;
    border: 1px solid;
    padding: 10px;
}
</style>

<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <div class="txt">
        <h1>تتبع رحلاتك عبر الانترنت</h1>
        <h1>Track Your Travels Online</h1>
      </div>
      <img style="height: 88vh;" class="d-block w-100" src="https://assets.entrepreneur.com/content/3x2/2000/1652366863-GettyImages-1140371673.jpg" alt="Third slide">
    </div>
    <div class="carousel-item">
      <div class="txt">
        <h2>تتبع رحلاتك عبر الانترنت</h2>
        <h2>Track Your Travels Online</h2>
      </div>
      <img style="height: 88vh;" class="d-block w-100" src="https://www.wondriumdaily.com/wp-content/uploads/2021/04/Airline-Feature-1-1024x555.jpg" alt="First slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<?php
    require_once('footer.php');
?>